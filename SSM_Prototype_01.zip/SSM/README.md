# SSM — Smart Sistem Manager
Prototype awal. Buka index.html untuk uji lokal. Tahap berikutnya: Supabase, autentikasi, master LKS, transaksi, External Radar/API, ELVORA, lalu deploy Web/APK.
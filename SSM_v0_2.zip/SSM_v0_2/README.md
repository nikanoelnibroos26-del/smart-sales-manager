# SSM v0.2 — Smart Sistem Manager
Fondasi UI + local demo. Fokus pengguna: LAPANGAN. SSM/ELVORA menangani sistem, data, analisis, dan workflow.

Sudah ada:
- Dashboard utama
- ELVORA command + CATAT/TIDAK DICATAT untuk contoh retur
- CRM sekolah dengan anti-duplikat NPSN
- status prospek/closing
- Master mapel SD aktif tanpa Bahasa Jawa
- Inventori, Keuangan, Pusat, Aktivitas, Laporan
- External Radar sebagai pintu integrasi data eksternal
- AI Workspace / Production Gate
- schema Supabase awal

Cara uji:
1. Buka index.html.
2. Tambahkan sekolah pada CRM.
3. Di Dashboard kirim: Sekolah 08 NPS***** retur 18 LKS.
4. Uji CATAT dan TIDAK DICATAT.
5. Buka External Radar.

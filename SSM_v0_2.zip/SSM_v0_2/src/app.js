const SUBJECTS=["Bahasa Indonesia","Bahasa Inggris","IPAS","Informatika","Matematika","PAI dan Budi Pekerti","Penjasorkes","Pendidikan Pancasila","Seni Musik","Seni Rupa"];
const SKEY="ssm_v02_schools", RKEY="ssm_v02_returns", AKEY="ssm_v02_activity";
let schools=load(SKEY), returns=load(RKEY), activities=load(AKEY);
const $=id=>document.getElementById(id);
function load(k){try{return JSON.parse(localStorage.getItem(k)||"[]")}catch{return[]}}
function save(k,v){localStorage.setItem(k,JSON.stringify(v))}
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function nav(){document.querySelectorAll(".nav").forEach(b=>b.onclick=()=>{document.querySelectorAll(".nav").forEach(x=>x.classList.remove("active"));b.classList.add("active");document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));$(b.dataset.page).classList.add("active")})}
function render(){
 $("mSchools").textContent=schools.length;$("mProspects").textContent=schools.filter(s=>s.status!=="CLOSING").length;$("mReturns").textContent=returns.length;$("stockReturns").textContent=returns.length;
 const count=s=>schools.filter(x=>x.status===s).length;$("mustVisit").textContent=count("HARUS DIKUNJUNGI");$("followup").textContent=count("FOLLOW-UP");$("offer").textContent=count("PENAWARAN");$("closing").textContent=count("CLOSING");
 const q=($("schoolSearch").value||"").toLowerCase();const rows=schools.filter(s=>(s.name+" "+s.npsn+" "+s.principal).toLowerCase().includes(q));
 $("schoolTable").innerHTML=rows.length?rows.map(s=>`<div class="row"><div><b>${esc(s.name)}</b><small>${esc(s.level)} · NPSN ${esc(s.npsn||"-")} · ${esc(s.students||0)} siswa · ${esc(s.principal||"")}</small></div><span class="tag">${esc(s.status)}</span></div>`).join(""):"<p class='muted'>Belum ada data.</p>";
 $("recent").innerHTML=activities.length?activities.slice(-5).reverse().map(a=>`<p><b>${esc(a.type)}</b> — ${esc(a.text)}<br><small>${new Date(a.date).toLocaleString("id-ID")}</small></p>`).join(""):"Belum ada aktivitas.";
 $("activityList").innerHTML=activities.length?activities.slice().reverse().map(a=>`<div class="row"><div><b>${esc(a.type)}</b><br>${esc(a.text)}</div><small>${new Date(a.date).toLocaleString("id-ID")}</small></div>`).join(""):"Belum ada aktivitas.";
}
function addActivity(type,text){activities.push({type,text,date:new Date().toISOString()});save(AKEY,activities);render()}
function returnConfirm(q,school,npsn){
 returns.push({id:crypto.randomUUID?.()||Date.now(),quantity:q,school,npsn,date:new Date().toISOString(),status:"CATAT"});
 save(RKEY,returns);addActivity("RETUR",`${school} — ${q} LKS`);$("commandResult").innerHTML='<div class="success">Retur dicatat di mode lokal. Produk LKS tidak diarang karena tidak disebutkan.</div>';
}
function command(){
 const v=$("command").value.trim();if(!v)return;
 const m=v.match(/(\d+)\s*lks/i);
 if(/retur/i.test(v)&&m){
  const q=+m[1], school=(v.match(/^(.*?)\s+NPS/i)||[])[1]?.trim()||"Sekolah tidak disebutkan", npsn=(v.match(/NPS[\w*.-]*/i)||["-"])[0];
  $("commandResult").innerHTML=`<div class="confirm"><b>ELVORA memahami ini sebagai transaksi retur.</b><p>Sekolah: ${esc(school)}<br>NPSN: ${esc(npsn)}<br>Jumlah: ${q} LKS</p><p class="muted">Judul/produk belum disebutkan. Sistem tidak akan mengarang produk.</p><button id="confirm">CATAT</button><button id="cancel" class="danger">TIDAK DICATAT</button></div>`;
  $("confirm").onclick=()=>returnConfirm(q,school,npsn);$("cancel").onclick=()=>{$("commandResult").innerHTML='<div class="info">Tidak dicatat. Tidak ada perubahan data.</div>';addActivity("ELVORA","Perintah dibatalkan — tidak ada data yang dicatat.")};
 }else $("commandResult").innerHTML='<div class="info">ELVORA: perintah diterima. Parser ini masih tahap lokal; integrasi AI/API akan ditambahkan setelah fondasi database.</div>';
}
function addSchool(){
 const name=$("schoolName").value.trim();if(!name)return alert("Nama sekolah wajib diisi.");
 const npsn=$("schoolNpsn").value.trim();
 if(npsn&&schools.some(s=>s.npsn===npsn))return alert("NPSN sudah ada. SSM mencegah duplikasi.");
 const s={id:crypto.randomUUID?.()||Date.now(),name,npsn,students:$("schoolStudents").value,level:$("schoolLevel").value,principal:$("schoolPrincipal").value,address:$("schoolAddress").value,status:$("schoolStatus").value,source:"manual",created_at:new Date().toISOString()};
 schools.push(s);save(SKEY,schools);addActivity("SEKOLAH",`Mencatat ${name}`);["schoolName","schoolNpsn","schoolStudents","schoolPrincipal","schoolAddress"].forEach(id=>$(id).value="");
}
$("subjects").innerHTML=SUBJECTS.map(s=>`<span>${s}</span>`).join("");
document.querySelectorAll(".nav").forEach(()=>{});nav();$("sendCommand").onclick=command;$("command").addEventListener("keydown",e=>{if(e.key==="Enter")command()});$("addSchool").onclick=addSchool;$("schoolSearch").oninput=render;
$("radarSearch").onclick=()=>{$("radarResult").innerHTML='<div class="external"><b>DATA EKSTERNAL — BELUM DIIMPOR</b><p>External Radar siap dihubungkan ke sumber web/API. Hasil eksternal tidak otomatis masuk SSM.</p><button onclick="this.parentElement.innerHTML=\'<b>CATAT</b> / <b>TIDAK DICATAT</b>\'">SIMULASI KONFIRMASI</button></div>'};
render();
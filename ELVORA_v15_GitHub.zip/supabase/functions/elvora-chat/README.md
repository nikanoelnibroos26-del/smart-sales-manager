# ELVORA v15 — GitHub Handoff

Target repository path:
`supabase/functions/elvora-chat/`

Supabase project: `wttbhygmaceehwarzxse`
Edge Function: `elvora-chat`
Deployed version: `15`
JWT verification: `true`
Deployed SHA: `c48e6faafd9746aad1b18dafef87eb0e101f996b2a6b62be9ab5833c18468bfd`

`deno.json` is included for the Edge Function runtime.

The deployed `index.ts` is the authoritative v15 source retrieved from Supabase. GitHub commit and Vercel deployment remain manual.

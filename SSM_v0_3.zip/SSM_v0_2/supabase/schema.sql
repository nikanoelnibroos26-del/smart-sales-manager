-- SSM v0.3 — Phase 2 foundation
create extension if not exists pgcrypto;

create table if not exists public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  created_at timestamptz not null default now()
);

create table if not exists public.organization_members (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'member' check (role in ('owner','admin','member','viewer')),
  created_at timestamptz not null default now(),
  primary key (organization_id,user_id)
);

create table if not exists public.schools (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid references public.organizations(id) on delete set null,
  user_id uuid references auth.users(id) on delete set null,
  name text not null,
  npsn text,
  students integer not null default 0,
  level text not null check (level in ('SD','SMP','SMA/MA')),
  principal text,
  address text,
  status text not null default 'PROSPEK',
  source text not null default 'manual',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index if not exists schools_npsn_unique on public.schools(npsn) where npsn is not null and npsn <> '';

create table if not exists public.returns (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid references public.organizations(id) on delete set null,
  user_id uuid references auth.users(id) on delete set null,
  school_name text,
  npsn text,
  quantity integer not null check (quantity > 0),
  product_id uuid,
  status text not null default 'RECORDED',
  created_at timestamptz not null default now()
);

create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid references public.organizations(id) on delete set null,
  user_id uuid references auth.users(id) on delete set null,
  action text not null,
  entity_type text,
  entity_id uuid,
  before_data jsonb,
  after_data jsonb,
  reason text,
  created_at timestamptz not null default now()
);

create table if not exists public.data_lineage (
  id uuid primary key default gen_random_uuid(),
  entity_type text not null,
  entity_id uuid,
  source_type text not null,
  source_reference text,
  discovered_at timestamptz,
  imported_at timestamptz,
  verified_at timestamptz,
  verification_state text not null default 'UNVERIFIED',
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.schools enable row level security;
alter table public.returns enable row level security;
alter table public.audit_logs enable row level security;
alter table public.data_lineage enable row level security;

-- Initial owner-safe policies: authenticated users can manage only rows they created.
-- Organization-scoped policies will be tightened when membership bootstrap is implemented.
drop policy if exists schools_owner_access on public.schools;
create policy schools_owner_access on public.schools for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists returns_owner_access on public.returns;
create policy returns_owner_access on public.returns for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists profiles_self_access on public.profiles;
create policy profiles_self_access on public.profiles for all to authenticated using (id = auth.uid()) with check (id = auth.uid());

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin insert into public.profiles(id) values(new.id) on conflict do nothing; return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

// Isi dua nilai ini untuk menghubungkan SSM ke project Supabase.
// Gunakan Publishable/anon key saja di browser. Jangan pernah memasukkan service_role key.
window.SSM_SUPABASE = {
  url: "",
  publishableKey: ""
};

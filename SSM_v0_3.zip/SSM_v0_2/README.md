# SSM v0.3 — Phase 2 Foundation

**SSM — Smart Sistem Manager**

Repository target: `nikanoelnibroos26-del/smart-sales-manager`

## Yang dikerjakan
- Fondasi Supabase nyata: users/profiles, organizations, members.
- Login/daftar via Supabase Auth.
- Sekolah dan retur dapat dikirim ke Supabase setelah user login.
- RLS awal untuk membatasi data berdasarkan user pembuat.
- Audit log dan data lineage disiapkan sebagai fondasi.
- LocalStorage tetap dipakai sebagai mode fallback/demo.
- CATAT/TIDAK DICATAT tetap menjadi production gate pada perintah ELVORA.

## Cara menghubungkan Supabase
1. Buka project Supabase yang sudah dibuat.
2. Jalankan `supabase/schema.sql` di SQL Editor.
3. Ambil **Project URL** dan **Publishable key** (atau anon key bila dashboard lama menampilkannya).
4. Isi `src/supabase-config.js`:
   - `url`
   - `publishableKey`
5. Jangan masukkan `service_role` key ke browser atau repository.
6. Deploy repository ini ke Vercel.

## Status
Ini belum mengaktifkan seluruh modul produksi. Tahap berikutnya setelah fondasi database stabil adalah organisasi/role bootstrap, transaksi LKS, master 181 LKS, stok, pengantaran, pembayaran/piutang, Pusat, dan audit penuh.
